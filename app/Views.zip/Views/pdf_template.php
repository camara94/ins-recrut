<!DOCTYPE html>
<html>
<head>
    <title>Document PDF Bootstrap</title>
    <!-- Incluez les liens CSS Bootstrap ici -->
    <link rel="stylesheet">
</head>
<body>
    <div class="container">
        <h1>Exemple de document PDF Bootstrap</h1>
        <?= site_url().'/public/assets/images/logo-rgph4.jpg' ?>
        <p>Ceci est un exemple de document PDF généré à partir de Bootstrap.</p>
    </div>
</body>
</html>
