<?php echo view('admin/includes/header') ?>

<?php echo  view($admin_content);?>

<?php echo  view('admin/includes/footer') ;?>