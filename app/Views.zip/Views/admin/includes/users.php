
<?= $this->extend('admin/includes/base') ?>

<?= $this->section('title') ?>
    Online recruitment INS
<?= $this->endSection() ?>

<?= $this->section('content') ?>
<section class="">
    <div class="row">
        <div class="col-xl-12 col-md-12 col-12">   
            <h1 class="my-2">Utilisateurs <a href="<?= site_url('useradd',)?>" class="float-righ"> + </a> </h1>
            <div class="">                   
                <table id="example" class="table table-striped table-bordered" style="width:100%">
                    <thead>
                        <tr>
                            <th>N°</th>
                            <th>Prénoms</th>
                            <th>Nom</th>
                            <th>Phones</th>
                            <th>Emails</th>
                            <th>&nbsp;</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $i = 0; ?>
                        <?php foreach ($users as $key => $value):?>
                        <?php $i++; ?>
                        <tr>
                            <td><?= $i ?></td>
                            <td><?= $value->last_name; ?></td>
                            <td><?= $value->name ?></td>
                            <td><?= $value->phone;?></td>
                            <td><?= $value->email;?></td>
                            <td class="text-right">
                                <a href="<?= site_url('useredit/'.$value->id); ?>" class='btn btn-primary btn-sm'> <i class="fa fa-edit" aria-hidden="true"></i> Edit</a>
                                <a href="<?= site_url('userdelete/'.$value->id); ?>" class='btn btn-danger btn-sm'> <i class="fa fa-trash" aria-hidden="true"></i> Delete</a>
                            </td>
                        </tr>                            
                        <?php endforeach;?>                        
                    </tbody>                    
                </table>
            </div>
        </div>            
    </div>
</section>

<?= $this->endSection() ?>

<?= $this->section('script') ?>
<script>
    $(document).ready(function () {
        $('#example').DataTable();
    });
</script>
<?= $this->endSection() ?>