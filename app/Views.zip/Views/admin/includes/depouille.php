
<?= $this->extend('admin/includes/base') ?>

<?= $this->section('title') ?>
    Online recruitment INS
<?= $this->endSection() ?>

<?= $this->section('style') ?>
    <style>
        .docs{
            height:900px; 
            /* border:5px solid red; */
            overflow-y: scroll; 
        }
    </style>
<?= $this->endSection() ?>

<?= $this->section('content') ?>
<!-- pour recupere  la variable prefecture id -->

<section class="dasbord_section">
    <div class="row">       
        
        <form class="col-12 mt-3" action="/index.php/postulant/depouille" method="POST">
            <?php foreach ($person as $key => $value):?>
                <div class="row border-bottom mb-2">
                    <div class="col">
                        <div class="h2 pb-3 text-uppercase">DEPOUILLEMENT DE DOSSIERS (<?= $value->matricule ?> <?= $value->name ?> <?= $value->last_name ?> )</div>
                    </div>
                </div>
                <div class="row border-bottom">
                    <div class="col-1 image"> 
                    <?php
                        $image_path = 'uploads/files/'.$value->photo;
                        if(file_exists($image_path)) {
                            echo '<img src="' .base_url($image_path).'" alt="PHOTO ..." class="rounded">';
                        }else {
                            echo'<img src="'.base_url('assets/images/logo-rgph4.jpg').'" alt="PHOTO ..." class="img-flui" class="rounded" />';
                        }
                    ?>                         
                    </div>
                    <div class="col-3">
                        <div class="row mb-1"> <div class="col"> <h1 class="bg-info p-2">Informations</h1> </div> </div>
                        <div class="row mb-1"> <div class="col font-weight-bold"> Matricule </div> <div class="col"> <?= $value->matricule ?> </div> </div>
                        <div class="row mb-1"> <div class="col font-weight-bold"> Prénoms </div> <div class="col"> <?= $value->name ?> </div> </div>
                        <div class="row mb-1"> <div class="col font-weight-bold"> Nom </div> <div class="col"> <?= $value->last_name ?> </div> </div>
                        <div class="row mb-1"> <div class="col font-weight-bold"> Sexe </div> <div class="col"> <?= $value->sexe ?> </div> </div>
                        <div class="row mb-1"> <div class="col font-weight-bold"> Phone </div> <div class="col"> <?= $value->contact1 ?> </div> </div>
                        <div class="row mb-1"> <div class="col font-weight-bold"> Email </div> <div class="col"> <?= $value->email ?> </div> </div>
                        <div class="row mb-1"> <div class="col font-weight-bold"> Pièce </div> <div class="col"> <?= strtoupper($value->type_piece) ?> <?= $value->numero_cni ?> </div> </div>
                        <div class="row mb-1"> <div class="col font-weight-bold"> Naissance </div> <div class="col"> <?= strtoupper($value->lieu_naiss) ?> - <?= $value->date_naiss ?> </div> </div>                  
                        <div class="row mb-1"> <div class="col font-weight-bold"> Papa </div> <div class="col"> <?= $value->namepere ?> </div> </div>
                        <div class="row mb-1"> <div class="col font-weight-bold"> Maman </div> <div class="col"> <?= $value->namemere ?> </div> </div>
                        <div class="row mb-1"> <div class="col font-weight-bold"> Tuteur </div> <div class="col"> <?= $value->nomtuteurlegal ?> </div> </div>
                        <div class="row mb-1"> <div class="col font-weight-bold"> Contact Tuteur </div> <div class="col"> <?= $value->contact2 ?> </div> </div>
                        <!-- <div class="row mb-1"> <div class="col font-weight-bold"> Statut </div> <div class="col"> <?= $value->status ?> </div> </div> -->
                        <div class="row mb-1"> <div class="col font-weight-bold"> Niveaux d'Etudes </div> <div class="col"> <?= $value->niveau_etude ?> </div> </div>
                        <div class="row mb-1"> <div class="col font-weight-bold"> Langues Parlées </div> <div class="col"> <?= $value->langue1.'/'.$value->langue2.'/'.$value->langue3 ?> </div> </div>
                        <div class="row mb-1"> <div class="col font-weight-bold"> Experiences </div> <div class="col"> <?= $value->exp_intitule_poste ?> </div> </div>
                        <div class="row mt-3"> 
                            <div class="col font-weight-bold"> 
                                <h1 class="bg-info p-2">Sélectionner les dossiers</h1> 
                                <?php if(!empty($value->cv)){?>  
                                <div class="custom-control custom-checkbox mt-2">
                                    <input type="checkbox" class="custom-control-input" name="checkCV" value="1" id="checkCV" <?php if($depouillements->cv == 1) echo " checked"; ?>>
                                    <label class="custom-control-label" for="checkCV">Curriculum Vitae</label>
                                </div>
                                <?php }?>  
                                
                                <div class="custom-control custom-checkbox mt-2">
                                    <input type="checkbox" class="custom-control-input" name="checkPI" value="1" id="checkPI" <?php if($depouillements->pi == 1) echo " checked"; ?>>
                                    <label class="custom-control-label" for="checkPI"> Pièce d'Identité</label>
                                </div>
                                
                                <div class="custom-control custom-checkbox mt-2">
                                    <input type="checkbox" class="custom-control-input" name="checkCM" value="1" id="checkCM" <?php if($depouillements->cm == 1) echo " checked"; ?>>
                                    <label class="custom-control-label" for="checkCM">Certificat Médical</label>
                                </div> 

                                <div class="custom-control custom-checkbox mt-2">
                                    <input type="checkbox" class="custom-control-input" id="checkAE" name="checkAE" value="1" <?php if($depouillements->ae == 1) echo " checked"; ?>>
                                    <label class="custom-control-label" for="checkAE">Attestation d'Expérience</label>
                                </div> 
                                <div class="custom-control custom-checkbox mt-2">
                                    <input type="checkbox" class="custom-control-input" id="checkDE" name="checkDE" value="1" <?php if($depouillements->de == 1) echo " checked"; ?>>
                                    <label class="custom-control-label" for="checkDE">Diplome d'Etude</label>
                                </div> 
                                
                                <div class="custom-control custom-checkbox mt-2">
                                    <input type="checkbox" class="custom-control-input" id="checkCR" name="checkCR" value="1" <?php if($depouillements->cr == 1) echo " checked"; ?>>
                                    <label class="custom-control-label" for="checkCR">Certificat de Residence</label>
                                </div> 

                                <div class="custom-control custom-checkbox mt-2">
                                    <input type="checkbox" class="custom-control-input" id="checkCJ" name="checkCJ" value="1" <?php if($depouillements->cj == 1) echo " checked"; ?>>
                                    <label class="custom-control-label" for="checkCJ">Casier Judiciaire</label>
                                </div> 
                            </div>
                        </div>
                        <div class="row mb-1"> <div class="col text-center"> <button class="btn btn-primary">Valider le depouillement</button> </div> </div>
                    </div>
                    <div class="col-8 docs">   
                        <!-- cv -->
                        <?php if(!empty($value->cv)){?>  
                            <div class="row mb-1"> 
                                <div class="col p-0"> 
                                    <div class="font-weight-bold text-center">
                                        <h2 class="display-6 font-weight-bold text-primary"> CV </h2> 
                                    </div>
                                    <section class="border">
                                        <?php if(strtolower(strrchr($value->cv, '.')) == ".pdf"){ ?>  
                                            <iframe src="<?= base_url("uploads/files/".$value->cv) ?>" width="100%" height="800"></iframe>
                                        <?php } else{ ?>
                                            <img src="<?= base_url("uploads/files/".$value->cv) ?>" alt="CV..." class="img-fluid">
                                        <?php } ?>
                                    </section>                              
                                </div> 
                            </div>   
                        <?php } ?> 
                        <!-- cni -->
                        <?php if(!empty($value->cni)){?>  
                            <div class="row mb-1"> 
                                <div class="col p-0"> 
                                    <div class="font-weight-bold text-center">
                                        <h2 class="display-6 font-weight-bold text-primary"> PIECE D'IDENTITE </h2> 
                                    </div>
                                    <section class="border">
                                        <?php if(strtolower(strrchr($value->cni, '.')) == ".pdf"){ ?>  
                                            <iframe src="<?= base_url("uploads/files/".$value->cni) ?>" width="100%" height="800"></iframe>
                                        <?php } else{ ?>
                                            <img src="<?= base_url("uploads/files/".$value->cni) ?>" alt="CNI..." class="img-fluid">
                                        <?php } ?>
                                    </section>                              
                                </div> 
                            </div>   
                        <?php } ?> 




                        <?php if(!empty($value->certifmedical)){?>  
                            <div class="row mb-1"> 
                                <div class="col p-0"> 
                                    <div class="font-weight-bold text-center">
                                        <h2 class="display-6 font-weight-bold text-primary"> Certificat Médical </h2> 
                                    </div>
                                    <section class="border">
                                        <?php if(strtolower(strrchr($value->certifmedical, '.')) == ".pdf"){ ?>  
                                            <iframe src="<?= base_url("uploads/files/".$value->certifmedical) ?>" width="100%" height="800"></iframe>
                                        <?php } else{ ?>
                                            <img src="<?= base_url("uploads/files/".$value->certifmedical) ?>" alt="Certificat Médical..." class="img-fluid">
                                        <?php } ?>
                                    </section>                              
                                </div> 
                            </div>   
                        <?php } ?> 
                        
                        <!-- Attestation d'Expérience -->
                        <?php if(!empty($value->attestcollecte)){?>  
                            <div class="row mb-1"> 
                                <div class="col p-0"> 
                                    <div class="font-weight-bold text-center">
                                        <h2 class="display-6 font-weight-bold text-primary"> Attestation d'Expérience </h2> 
                                    </div>
                                    <section class="border">
                                        <?php if(strtolower(strrchr($value->attestcollecte, '.')) == ".pdf"){ ?>  
                                            <iframe src="<?= base_url("uploads/files/".$value->attestcollecte) ?>" width="100%" height="800"></iframe>
                                        <?php } else{ ?>
                                            <img src="<?= base_url("uploads/files/".$value->attestcollecte) ?>" alt="Attestation d'Expérience..." class="img-fluid">
                                        <?php } ?>
                                    </section>                              
                                </div> 
                            </div>   
                        <?php } ?>

                        <!-- Diplome d'Etude -->
                        <?php if(!empty($value->doc_last_diplome)){?>  
                            <div class="row mb-1"> 
                                <div class="col p-0"> 
                                    <div class="font-weight-bold text-center">
                                        <h2 class="display-6 font-weight-bold text-primary"> Diplome d'Etude </h2> 
                                    </div>
                                    <section class="border">
                                        <?php if(strtolower(strrchr($value->doc_last_diplome, '.')) == ".pdf"){ ?>  
                                            <iframe src="<?= base_url("uploads/files/".$value->doc_last_diplome) ?>" width="100%" height="800"></iframe>
                                        <?php } else{ ?>
                                            <img src="<?= base_url("uploads/files/".$value->doc_last_diplome) ?>" alt=" Diplome d'Etude ..." class="img-fluid">
                                        <?php } ?>
                                    </section>                              
                                </div> 
                            </div>   
                        <?php } ?>

                        <!-- Certificat de Residence -->
                        <?php if(!empty($value->certifresidence)){?>  
                            <div class="row mb-1"> 
                                <div class="col p-0"> 
                                    <div class="font-weight-bold text-center">
                                        <h2 class="display-6 font-weight-bold text-primary"> Certificat de Residence </h2> 
                                    </div>
                                    <section class="border">
                                        <?php if(strtolower(strrchr($value->certifresidence, '.')) == ".pdf"){ ?>  
                                            <!-- <iframe src="<?= base_url("uploads/files/".$value->certifresidence) ?>" width="100%" height="800"></iframe> -->
                                            <iframe src="<?= base_url("uploads/files/".$value->certifresidence) ?>" width="100%"></iframe>
                                        <?php } else{ ?>
                                            <img src="<?= base_url("uploads/files/".$value->certifresidence) ?>" alt="Certificat de Residence ..." class="img-fluid">
                                        <?php } ?>
                                    </section>                              
                                </div> 
                            </div>   
                        <?php } ?>

                        <!-- Casier Judiciaire -->
                        <?php if(!empty($value->casier)){?>  
                            <div class="row mb-1"> 
                                <div class="col p-0"> 
                                    <div class="font-weight-bold text-center">
                                        <h2 class="display-6 font-weight-bold text-primary"> Casier Judiciaire </h2> 
                                    </div>
                                    <section class="border">
                                        <?php if(strtolower(strrchr($value->casier, '.')) == ".pdf"){ ?>  
                                            <iframe src="<?= base_url("uploads/files/".$value->casier) ?>" width="100%" height="800"></iframe>
                                        <?php } else{ ?>
                                            <img src="<?= base_url("uploads/files/".$value->casier) ?>" alt="Certificat de Residence ..." class="img-fluid">
                                        <?php } ?>
                                    </section>                              
                                </div> 
                            </div>   
                        <?php } ?>

                    </div>
                </div>
                <input type="hidden" value="<?= $value->id ?>" name="postulant_id">
            <?php endforeach;?>           
        </form>             
    </div>
</section>

<?= $this->endSection() ?>

<?= $this->section('script') ?>
<script>
    $(document).ready(function () {
        // $('#example').DataTable();
        $("#prefecture_id").change(function(){$idElem=$(this).val(); 
            $("#sp_id").val("0"); $("#sp_id option").hide(); 
            $('#sp_id .optElem'+$idElem+', #sp_id .optElem0').show();
        })

    });
</script>
<?= $this->endSection() ?>

<?= $this->section('style') ?>
<style>
    .image img{
        max-width:150px;
        max-height:150px;
    }
</style>
<?= $this->endSection() ?>








































