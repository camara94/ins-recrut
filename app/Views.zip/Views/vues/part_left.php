<div class="leftContener">
    <div style="border-left:3px solid black;padding:10px; font-size:12px;text-align:justify;  background-color: #e5e5e5;">
        L'Institut National de la Statistique (INS) vous souhaite la bienvenue sur le site du recrutement des différentes catégories de personnel de cet important projet pour notre pays.
    </div>
	 <div style="margin:20px 0px; background:#f9e6b7; padding:10px 0;">
		 <a href="<?php echo base_url().'recepisse'; ?>" style="text-decoration:none"><img src="<?php echo base_url('assets/images/new_button.gif'); ?>" width="30" style="float:left; margin-top:-4px" /><span style="font-size:16px; color:black;">Recupérer mon recepissé</span></a>
    </div>

  <div id="listPieceF" style=" ">
      <p>Listes des Pièces à Joindre</p>
      <ul>
         <li>Photo d'identité;</li> 
         <li>Carte Nationale d'identité (CNI) / Passeport / Attestation d'identité / Permis;</li> 
		   <li>Curriculum vitae(CV);</li> 
         <li>Copie du dernier diplôme;</li> 
         <li>Pièce d'identité de la personne garante;</li> 
         <li>Certificat de résidence</li> 
      </ul>
      <p class="top-10" style="text-decoration: none; color:red;text-align: justify;"><span style="font-weight: bold;text-decoration: underline">NB</span> : Tous les fichiers doivent être soit au format : pdf, jpeg ou jpg avec une taille de 2Mo maxi</p>
  </div>
   <div style="margin:20px 0 10px;font-weight: bold;">Comment postuler ?</div>
  <div style="padding:10px; font-size:14px;text-align:justify;">
        <p>Pour postuler, il faut : </p>
        <div class="post_vacant" style="border-top:none">
        <p>1- Cliquez sur <span style="color:red;font-weight:bold">l'intitul&eacute; du profil</span> en fonction du type de poste souhait&eacute; ou sur le bouton
             <span style="color:red;font-weight:bold">postuler</span> correspondant</p>
        </div>
        <div class="post_vacant">
        <p>2- Renseigner les informations demand&eacute;es. (<span style="color:red;font-weight:bold">NB: les champs (*) sont obligatoires</span>)</p>
        </div>
        <div class="post_vacant">
        <p>3- T&eacute;l&eacute;charger et imprimer le r&eacute;c&eacute;piss&eacute; g&eacute;n&eacute;r&eacute;</p>
        </div>
  </div>
    <div class="recrut_proj">
        <a href="<?php echo base_url();?>" style="display:block">revenir page accueil</a>
        <p></p>
    </div>



</div>