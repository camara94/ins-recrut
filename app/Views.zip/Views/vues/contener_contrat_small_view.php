<div style="display: block;text-align: center;background: #2b542c;padding: 5px;color:white;font-weight: bold">TERMES DE REFERENCE (TDR)</div>

<div class="top-10">
<?php echo $projet['contrat']; ?>
</div>

<div id="<?php echo $projet['id'];?>" style="margin:0; margin-top:20px;padding-bottom:10px; font-weight:bold">
            <input type="checkbox" name="lucontrat" value="1" required>J'ai lu l'avis et je comprends<br>
</div>
