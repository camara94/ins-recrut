<?php
require_once('views/part_left.php');
?>
 
<div class="rigthContener">
       <div style="margin-bottom:30px;text-decoration:underline; text-align:center; font-size:20px; font-weight:bold">
            NOUS CONTACTER
        </div>
         <!--information projet-->
        <div style="margin-bottom:15px;font-size:14px; font-weight:bold; ">Adresse : 
                <span style="font-weight:500; font-size:18px; color:black; text-decoration:underline">
                Kaloum ,Marché Niger, Bureau Central du Recensement</span>
        </div>
        <div style="margin-bottom:15px;font-size:14px; font-weight:bold;">T&#233;l&#233;phone : 
                <span style="font-weight:500; font-size:18px; color:black">+224 627 876 021/+224 661 311 175/+224 629 086 653</span>
        </div>
         
 </div>
