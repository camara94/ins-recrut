
<?php echo view('template/header') ?>

<?php echo  view($main_content);?>

<?php  echo  view('template/footer') ;?>